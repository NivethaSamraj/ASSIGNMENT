"""MODULE IS USED TO FIND SINH VALUE"""


def sin_h(x_value):
    """formula for finding sin"""
    exp_value = 2.71828
    sinh_of_x = (exp_value ** x_value - exp_value ** (- x_value)) / 2
    return sinh_of_x
