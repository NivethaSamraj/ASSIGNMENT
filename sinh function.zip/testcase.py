"""PRog"""
import unittest
import myprac




class MyTestCase(unittest.TestCase):
    """test case class"""
    def test_1(self):
        """positive value"""
        self.assertEqual(myprac.sin_h(30), 5343129467557.554)

    def test_2(self):
        """negative value"""
        self.assertEqual(myprac.sin_h(-1), -1.1752001556866842)


if __name__ == '__main__':
    unittest.main()
